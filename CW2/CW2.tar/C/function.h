double euler(double, double, double, int); 

double func1(double);  

